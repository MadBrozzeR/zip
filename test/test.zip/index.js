module.exports = {
  MBRZip: require('./zip-reader.js')
};
